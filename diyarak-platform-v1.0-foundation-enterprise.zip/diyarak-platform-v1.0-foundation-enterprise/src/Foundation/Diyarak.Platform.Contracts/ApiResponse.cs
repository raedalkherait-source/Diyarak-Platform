namespace Diyarak.Platform.Contracts;
public sealed record ApiResponse<T>(T? Data, ProblemContract? Problem, string? CorrelationId)
{
    public bool IsSuccess => Problem is null;
    public static ApiResponse<T> Success(T data, string? correlationId = null) => new(data, null, correlationId);
    public static ApiResponse<T> Failure(ProblemContract problem, string? correlationId = null) => new(default, problem ?? throw new ArgumentNullException(nameof(problem)), correlationId);
}
