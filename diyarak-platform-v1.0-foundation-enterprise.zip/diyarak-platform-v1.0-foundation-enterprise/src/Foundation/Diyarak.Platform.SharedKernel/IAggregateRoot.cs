namespace Diyarak.Platform.SharedKernel;
public interface IAggregateRoot { IReadOnlyCollection<IDomainEvent> DomainEvents { get; } void ClearDomainEvents(); }
