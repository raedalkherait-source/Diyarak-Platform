namespace Diyarak.Platform.SharedKernel;
public interface IBusinessRule { string Message { get; } bool IsBroken(); }
