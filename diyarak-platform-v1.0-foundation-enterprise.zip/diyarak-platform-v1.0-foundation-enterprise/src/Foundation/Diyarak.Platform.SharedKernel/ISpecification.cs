namespace Diyarak.Platform.SharedKernel;
public interface ISpecification<in T> { bool IsSatisfiedBy(T candidate); }
