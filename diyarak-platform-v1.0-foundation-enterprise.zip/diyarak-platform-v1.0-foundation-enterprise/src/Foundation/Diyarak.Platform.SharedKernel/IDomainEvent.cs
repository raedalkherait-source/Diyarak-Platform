namespace Diyarak.Platform.SharedKernel;
public interface IDomainEvent { Guid EventId { get; } DateTimeOffset OccurredOnUtc { get; } }
