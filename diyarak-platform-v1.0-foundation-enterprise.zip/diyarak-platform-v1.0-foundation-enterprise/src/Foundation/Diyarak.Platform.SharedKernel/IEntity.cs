namespace Diyarak.Platform.SharedKernel;
public interface IEntity<out TId> where TId : notnull { TId Id { get; } }
