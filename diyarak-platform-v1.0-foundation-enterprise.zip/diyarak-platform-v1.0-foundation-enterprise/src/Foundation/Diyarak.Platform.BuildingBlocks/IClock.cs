namespace Diyarak.Platform.BuildingBlocks;
public interface IClock { DateTimeOffset UtcNow { get; } }
