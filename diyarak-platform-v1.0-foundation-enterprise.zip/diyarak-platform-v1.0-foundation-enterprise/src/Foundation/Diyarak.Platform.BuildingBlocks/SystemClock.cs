namespace Diyarak.Platform.BuildingBlocks;
public sealed class SystemClock : IClock { public static SystemClock Instance { get; } = new(); private SystemClock() { } public DateTimeOffset UtcNow => DateTimeOffset.UtcNow; }
